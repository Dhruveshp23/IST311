class DigitalBook extends Book {
    public DigitalBook(String title, String author) {
        super(title, author);
    }
}